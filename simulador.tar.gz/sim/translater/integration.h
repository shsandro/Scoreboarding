#ifndef INTEGRATION_H
#define INTEGRATION_H

#include <stdio.h>

FILE *input_assembly;
FILE *output;

#endif